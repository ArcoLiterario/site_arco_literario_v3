const hamburguer = document.querySelector('.hamburger');

const navItems = document.querySelector('.ul-header');

hamburguer.addEventListener("click", () =>{
    hamburguer.classList.toggle("active");
    navItems.classList.toggle("active");
})