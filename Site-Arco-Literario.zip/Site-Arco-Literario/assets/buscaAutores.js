const pesquisa = document.querySelector("#botao_pesquisar")
const autores = document.querySelectorAll(".card");
const failMessage = document.querySelector(".failMessage p");

let cont;

pesquisa.addEventListener("keyup", () => {
    let valorPesquisar = pesquisa.value.toLowerCase();
    if(valorPesquisar === ""){
        autores.forEach(e => {
            e.style.display = "";
        });
    }else{
        cont = 0;
        autores.forEach(e => {
            let nomeAutor = e.children[1].textContent.toLowerCase();
            if(nomeAutor.includes(valorPesquisar)){
                e.parentElement.style.display = ""
            }
            else{
                cont ++;
                e.parentElement.style.display = "none"
            }
        });
        if(cont === autores.length){
            failMessage.innerHTML = "Parece que não há nenhum autor com esse nome por aqui :("
        }else{
            failMessage.innerHTML = ""
        }
    }
})



//Parece que não há nenhum autor com esse nome por aqui :(

    
